#-------------IMPORTATION DES LIBRAIRIES----------------------#

import os
import json
import random
import warnings
import streamlit as st

from functions import pdfloader 

from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Qdrant
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA

random.seed(123)
warnings.filterwarnings(action = 'ignore')

#-------------CHARGEMENT DES DONNEES----------------------------#

# Récupération de la clé OpenAI
with open("OpenAIkey.txt", "r") as file:
    mykey = file.read().strip()  

os.environ["OPENAI_API_KEY"] = mykey

# Chargement des documents
Documents = pdfloader("Docs/")

#-------------VECTORISATION & CREATION DU RAG-------------------#

# Embeddings & Vectorstore.db
openAIembedding = OpenAIEmbeddings(model="text-embedding-ada-002")

vectorstore = Qdrant.from_documents(
                                    Documents,  
                                    openAIembedding,
                                    location=":memory:", 
                                    collection_name="Vectordb",  
                                   )


# Chargement du modèle utiliser pour le RAG
gpt4 = ChatOpenAI(model_name="gpt-4-turbo-preview", temperature=0)

# Créer un retriever
retriever = vectorstore.as_retriever(search_type="similarity", 
                                     search_kwargs={"k": 15}
                                     )

# Créer la chaîne RetrievalQA
qa_chain = RetrievalQA.from_chain_type(
                                        llm=gpt4,
                                        chain_type="stuff",
                                        retriever=retriever,
                                        return_source_documents=True
                                      )

#-------------FONCTIONS------------------------------------------#

# Fonction pour collecter les feedbacks des utilisateurs
@st.cache_data
def collect_feedback(question, response, feedback):
    
    # Un dictionnaire pour stocker les retours utilisateurs
    feedback_store = {}
    
    feedback_store[question] = {"response": response, "feedback": feedback}

    return feedback_store

@st.cache_data
def load_feedbacks():

    try:
        with open("feedbacks.json", "r", encoding="utf-8") as f:
            content = f.read()
            if content:  # Si le fichier n'est pas vide
                return json.loads(content)
            else:  # Si le fichier est vide, on retourne un dictionnaire vide
                return {}
    except (FileNotFoundError, json.JSONDecodeError):  # Si le fichier n'existe pas ou est corrompu
        return {}

#-------------IMPLEMENTATION DANS LE STREAMLIT-------------------#

# Charger feedbacks
feedback_store = load_feedbacks()


nom = "SOFIDY - Société de Gestion de Fonds Immobiliers"
st.markdown(f"""<h1 style="font-size:50px; color: dark; text-align: left;"
                >{nom}</h1>""",unsafe_allow_html=True)
# Entrée utilisateur


st.markdown(f"""<h2 style="font-size:40px; color: blue; text-align: left;"
                >Foire aux Questions ?</h2>""",unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)

text = """Bonjour, je suis Fric, votre assistant conversationnel. 
            Comment puis-je vous aider ?
        """

user_question = st.text_input(text)
result, feedback = str(), str()

if user_question:
    # Obtenir la réponse à partir du modèle RAG
    response = qa_chain({"query": user_question})
    result = response['result']
    
    # Afficher la réponse
    st.write("Réponse :", response['result'])
    
    # Collecter le feedback utilisateur
    feedback = st.radio("Feedback", ["Correct", "Incorrect"])
    
    # Enregistrer le feedback lorsque l'utilisateur clique sur "Envoyer le feedback"
    if st.button("Envoyer le feedback"):
        feedback_store[user_question] = {
            "Réponse_RAG": result,
            "Feedback_utilisateur": feedback
        }
        
        # Sauvegarder les feedbacks mis à jour dans le fichier JSON
        with open("feedbacks.json", "w", encoding="utf-8") as f:
            json.dump(feedback_store, f, indent=4, ensure_ascii=False)
        
        st.success("Merci pour votre feedback !")
