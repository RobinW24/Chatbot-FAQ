import os
from langchain.document_loaders import PyPDFLoader

# Fonction pour charger les documents pdf
def pdfloader(folder:str) -> list:

    """--Docstring--
    
    Args: 
        folder: string object (files directory path)
    
    function return a list
    """
    documents = []
    
    for doc in os.listdir(folder):
        file_path = os.path.join(folder, doc)
        file = PyPDFLoader(file_path).load()
        documents.extend(file)
    
    print(f"Nombre Total de pages: {len(documents)}")
    return documents