# Generative AI
- Build a ChatBot (Retrieval Augmented Generation - RAG) for an enterprise to give peoples informations on financial products
